The SocialHub web app is included as socialhub_starter.html.
MainActivity loads this file from app/src/main/assets/.
