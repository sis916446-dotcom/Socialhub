SOCIALHUB ANDROID PROJECT — በአማርኛ

ይህ ፕሮጀክት HTML ፋይሉን በAndroid WebView ውስጥ የሚያሳይ መሠረታዊ APK ፕሮጀክት ነው።
Social media API አያገናኝም፤ HTML ውስጥ ያለው የሙከራ ይዘት ብቻ ነው።

የሚያስፈልግ:
1. የGitHub መለያ (ነፃ ሊሆን ይችላል)
2. የSocialHub HTML ፋይል

የGitHub Actions መንገድ:
1. ይህን ZIP አውርድና ከፍተህ ያለውን SocialHubAndroid ፎልደር ተመልከት።
2. app/src/main/assets/ ውስጥ socialhub_starter.html በሚለው ስም ያለ HTML ፋይል አስቀምጥ።
3. ፎልደሩን GitHub repository ውስጥ አስገባ።
4. GitHub ላይ Actions tab > Build SocialHub APK > Run workflow ምረጥ።
5. ሲጨርስ Actions run ክፈት፤ Artifacts ስር SocialHub-debug-apk አውርድ።
6. ZIP artifact ን ከፍተህ app-debug.apk ን በስልክህ ላይ ጫን።

ማስታወሻ:
- Debug APK ለሙከራ ነው፤ Play Store ለማስገባት የተለየ release signing ያስፈልጋል።
- GitHub ላይ አታውጣ የምትፈልጋቸውን ሚስጥራዊ ቁልፎች ወይም passwords አታስገባ።
- HTML ፋይሉ የተጠቃሚውን localStorage ይጠቀማል፤ app data ሲጠፋ የተቀመጠ ይዘት ሊጠፋ ይችላል።
